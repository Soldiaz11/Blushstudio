# Sitio web — Blush Digital Studio

Sitio estático (HTML, CSS y JavaScript puro), pensado para cargar rápido y posicionar bien en Google.

## Estructura

```
sitio-sol-diaz/
├── index.html                      Inicio (queda en la raíz)
├── 404.html                        Página de error (queda en la raíz)
├── pages/
│   ├── paginas-web.html            Servicio: Páginas web
│   ├── tiendas-online.html         Servicio: Tiendas y catálogos online
│   ├── automatizaciones.html       Servicio: Automatizaciones
│   ├── rediseno-web.html           Servicio: Rediseño web
│   ├── desarrollos-a-medida.html   Servicio: Desarrollos a medida
│   ├── servicios.html              Todos los servicios (página general)
│   ├── proyectos.html              Proyectos con filtros
│   ├── sobre-nosotros.html         Sobre nosotros
│   ├── contacto.html               Formulario, WhatsApp y email
│   └── gracias.html                Después de enviar el formulario (no se indexa)
├── css/styles.css                  Estilos (colores y tipografías arriba de todo)
├── js/main.js                      Menú, filtros y formulario
├── img/                            Isotipo, íconos, fotos e imagen para compartir
└── robots.txt, sitemap.xml, site.webmanifest, .htaccess
```

## Cómo abrirlo en VS Code

1. Descomprimí el zip y abrí la carpeta `sitio-sol-diaz` (Archivo > Abrir carpeta).
2. Instalá la extensión **Live Server**.
3. Clic derecho sobre `index.html` > **Open with Live Server**.

## Antes de publicar

- Con **Buscar y reemplazar en todos los archivos** (Ctrl/Cmd + Shift + H), reemplazá `https://www.tudominio.com.ar` por tu dominio (sin barra al final).
- En `pages/proyectos.html`, reemplazá los `href="#"` de "Ver proyecto" por los links de cada proyecto cuando estén publicados.
- Revisá el compromiso "Respuesta en 24 h hábiles" y ajustalo si hace falta.
- WhatsApp: +54 9 11 3170-7853 (`5491131707853`). Email: solagudiaz@gmail.com.

## Formulario de contacto

- **Enviar por WhatsApp:** arma el mensaje con los datos del formulario.
- **Enviar por email:** usa [FormSubmit](https://formsubmit.co). La primera vez te llega un mail para activarlo.
- Los botones de cada servicio abren el formulario con ese servicio ya seleccionado.

## Identidad visual

- **Logo:** isotipo en `img/blush-isotipo.png`; el texto "BLUSH / DIGITAL STUDIO" se arma con Montserrat (clases `.logo-*`).
- **Tipografías:** Montserrat para títulos, botones y menú; Inter para los textos.
- **Fotos:** `img/blush-*.webp`, en dos tamaños. Son fotos de Pexels recortadas y con un tono rosado para que combinen con la marca.
- **Voz:** el sitio habla como estudio ("diseñamos", "te enviamos").

## SEO incluido

- Una página por servicio, con título, descripción, preguntas frecuentes y enlaces internos.
- URL canónica, Open Graph y Twitter en todas las páginas.
- Datos estructurados (negocio, servicios, preguntas frecuentes, migas de pan).
- `sitemap.xml`, `robots.txt` e idioma declarado.

## Después de publicar

1. Agregá tu dominio en **Google Search Console** y enviá `sitemap.xml`.
2. Probá el sitio en **PageSpeed Insights**.
