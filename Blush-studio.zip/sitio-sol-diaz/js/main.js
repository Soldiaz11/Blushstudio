/* =========================================================
   Sol Díaz — JavaScript del sitio
   Menú hamburguesa, submenús, header al hacer scroll,
   filtros del portfolio y año del footer.
   ========================================================= */
(function () {
  "use strict";

  var MOBILE_QUERY = window.matchMedia("(max-width: 1180px)");
  var header = document.querySelector(".site-header");
  var toggle = document.querySelector(".nav-toggle");
  var nav = document.getElementById("main-nav");

  /* ---------- Menú hamburguesa ---------- */
  function openMenu() {
    nav.classList.add("is-open");
    toggle.setAttribute("aria-expanded", "true");
    toggle.setAttribute("aria-label", "Cerrar menú");
    document.body.classList.add("menu-open");
  }

  function closeMenu() {
    nav.classList.remove("is-open");
    toggle.setAttribute("aria-expanded", "false");
    toggle.setAttribute("aria-label", "Abrir menú");
    document.body.classList.remove("menu-open");
    closeAllSubmenus();
  }

  if (toggle && nav) {
    toggle.addEventListener("click", function () {
      if (nav.classList.contains("is-open")) {
        closeMenu();
      } else {
        openMenu();
      }
    });

    // Cerrar al tocar un link del menú en celular
    nav.querySelectorAll("a").forEach(function (link) {
      link.addEventListener("click", function () {
        if (MOBILE_QUERY.matches) closeMenu();
      });
    });

    // Si se agranda la pantalla con el menú abierto, se resetea
    MOBILE_QUERY.addEventListener("change", function (e) {
      if (!e.matches) closeMenu();
    });
  }

  /* ---------- Submenús (Diseño web, Automatizaciones, Marketing) ---------- */
  var subToggles = document.querySelectorAll(".sub-toggle");

  function closeAllSubmenus(except) {
    subToggles.forEach(function (btn) {
      if (btn === except) return;
      btn.setAttribute("aria-expanded", "false");
      btn.closest(".has-sub").classList.remove("is-open");
    });
  }

  subToggles.forEach(function (btn) {
    btn.addEventListener("click", function (e) {
      e.stopPropagation();
      var item = btn.closest(".has-sub");
      var willOpen = btn.getAttribute("aria-expanded") !== "true";
      closeAllSubmenus(btn);
      btn.setAttribute("aria-expanded", String(willOpen));
      item.classList.toggle("is-open", willOpen);
    });
  });

  // Click afuera cierra submenús (escritorio)
  document.addEventListener("click", function (e) {
    if (!e.target.closest(".has-sub")) closeAllSubmenus();
  });

  // Tecla Escape cierra todo
  document.addEventListener("keydown", function (e) {
    if (e.key !== "Escape") return;
    var openSub = document.querySelector(".has-sub.is-open .sub-toggle");
    closeAllSubmenus();
    if (nav && nav.classList.contains("is-open")) {
      closeMenu();
      toggle.focus();
    } else if (openSub) {
      openSub.focus();
    }
  });

  /* ---------- Sombra del header al hacer scroll ---------- */
  if (header) {
    var onScroll = function () {
      header.classList.toggle("is-scrolled", window.scrollY > 8);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
  }

  /* ---------- Filtros del portfolio ---------- */
  var filterBtns = document.querySelectorAll(".filter-btn");
  var projects = document.querySelectorAll("[data-category]");

  filterBtns.forEach(function (btn) {
    btn.addEventListener("click", function () {
      var filter = btn.dataset.filter;
      filterBtns.forEach(function (b) {
        b.setAttribute("aria-pressed", String(b === btn));
      });
      projects.forEach(function (p) {
        var match = filter === "todos" || p.dataset.category === filter;
        p.hidden = !match;
      });
    });
  });


  /* ---------- Formulario de contacto ---------- */
  var form = document.querySelector(".contact-form");
  if (form) {
    // Servicio preseleccionado desde los botones de cada página (?servicio=...)
    var params = new URLSearchParams(window.location.search);
    var preset = params.get("servicio");
    var select = form.querySelector("#servicio");
    if (preset && select) {
      Array.prototype.forEach.call(select.options, function (opt) {
        if (opt.value === preset) opt.selected = true;
      });
    }

    // Enviar la consulta por WhatsApp con los datos del formulario
    var waBtn = form.querySelector("[data-send-whatsapp]");
    if (waBtn) {
      waBtn.addEventListener("click", function () {
        if (!form.reportValidity()) return;
        var get = function (id) {
          var el = form.querySelector("#" + id);
          return el && el.value.trim() ? el.value.trim() : "";
        };
        var lines = [
          "Hola, quisiera solicitar un presupuesto.",
          "",
          "Nombre: " + get("nombre"),
          "Negocio: " + get("negocio"),
          "Servicio: " + get("servicio")
        ];
        if (get("presupuesto")) lines.push("Presupuesto aproximado: " + get("presupuesto"));
        lines.push("", "Proyecto: " + get("mensaje"));
        var number = waBtn.getAttribute("data-send-whatsapp");
        window.open("https://wa.me/" + number + "?text=" + encodeURIComponent(lines.join("\n")), "_blank", "noopener");
      });
    }
  }


  /* ---------- Año automático en el footer ---------- */
  var year = document.getElementById("year");
  if (year) year.textContent = new Date().getFullYear();
})();
